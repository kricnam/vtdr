/*
 * usbd_desc.h
 *
 *  Created on: Aug 4, 2012
 *      Author: mxx
 */

#ifndef USBD_DESC_H_
#define USBD_DESC_H_



#endif /* USBD_DESC_H_ */
