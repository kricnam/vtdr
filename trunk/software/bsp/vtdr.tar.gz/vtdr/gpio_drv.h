/*
 * gpio_drv.h
 *
 *  Created on: Sep 5, 2012
 *      Author: mxx
 */

#ifndef GPIO_DRV_H_
#define GPIO_DRV_H_

void rt_hw_gpio_init(void);


#endif /* GPIO_DRV_H_ */
